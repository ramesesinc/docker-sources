#!/bin/bash

_stop_server() {
  echo "Stopping anubis server..."
  touch /apps/server/bin/.shutdown_pid
}

trap "_stop_server" SIGINT SIGTERM SIGHUP

if [ "x$WAIT_COUNT" = "x" ]; then
  sleep 1
else
  sleep $WAIT_COUNT
fi

cd /apps/server/bin
rm -f .osiris_pid
./run.sh

