#!/bin/bash
cd /apps/server/bin
./shutdown.sh

